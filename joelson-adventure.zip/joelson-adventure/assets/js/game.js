const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const victoryScreen = document.getElementById('victory-screen');
const scoreElement = document.getElementById('ui');
const bgMusic = document.getElementById('bgMusic');

// Configurações do jogo
canvas.width = 800;
canvas.height = 400;
const GRAVITY = 0.5;
const JUMP_FORCE = -12;
const SPEED = 5;
const TILE_SIZE = 40;

// Estado do jogo
let score = 0;
let gameOver = false;
let gameWon = false;

// Input
const keys = {};
window.addEventListener('keydown', e => keys[e.code] = true);
window.addEventListener('keyup', e => keys[e.code] = false);

// Player (Joelson)
const player = {
    x: 50,
    y: 200,
    width: 30,
    height: 40,
    velX: 0,
    velY: 0,
    grounded: false,
    color: '#228b22', // Verde solicitado
    draw() {
        // Corpo
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x - camera.x, this.y, this.width, this.height);
        // Cabeça (Boné)
        ctx.fillStyle = '#000';
        ctx.fillRect(this.x - camera.x + 5, this.y - 10, 20, 10);
        // Rosto
        ctx.fillStyle = '#ffdbac';
        ctx.fillRect(this.x - camera.x + 10, this.y, 15, 15);
    }
};

// Câmera
const camera = {
    x: 0,
    width: canvas.width
};

// Level Design (0: Vazio, 1: Bloco, 4: Princesa Rayane)
const levelData = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,1,1,0,0,0,0,0,1,1,1,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];

const platforms = [];
const princess = { x: 0, y: 0, width: 30, height: 40 };

function initLevel() {
    for (let y = 0; y < levelData.length; y++) {
        for (let x = 0; x < levelData[y].length; x++) {
            if (levelData[y][x] === 1) {
                platforms.push({
                    x: x * TILE_SIZE,
                    y: y * TILE_SIZE,
                    width: TILE_SIZE,
                    height: TILE_SIZE
                });
            } else if (levelData[y][x] === 4) {
                princess.x = x * TILE_SIZE;
                princess.y = y * TILE_SIZE;
            }
        }
    }
}

function update() {
    if (gameWon) return;

    // Movimento lateral
    if (keys['ArrowLeft']) player.velX = -SPEED;
    else if (keys['ArrowRight']) player.velX = SPEED;
    else player.velX = 0;

    // Pulo
    if ((keys['ArrowUp'] || keys['Space']) && player.grounded) {
        player.velY = JUMP_FORCE;
        player.grounded = false;
    }

    // Gravidade
    player.velY += GRAVITY;
    player.x += player.velX;
    player.y += player.velY;

    // Colisões com plataformas
    player.grounded = false;
    for (let p of platforms) {
        if (player.x < p.x + p.width &&
            player.x + player.width > p.x &&
            player.y < p.y + p.height &&
            player.y + player.height > p.y) {
            
            if (player.velY > 0 && player.y + player.height - player.velY <= p.y) {
                player.y = p.y - player.height;
                player.velY = 0;
                player.grounded = true;
            }
            else if (player.velY < 0 && player.y - player.velY >= p.y + p.height) {
                player.y = p.y + p.height;
                player.velY = 0;
            }
            else if (player.velX > 0) {
                player.x = p.x - player.width;
            } else if (player.velX < 0) {
                player.x = p.x + p.width;
            }
        }
    }

    // Limites do mapa
    if (player.x < 0) player.x = 0;
    if (player.y > canvas.height) {
        player.x = 50;
        player.y = 200;
        player.velY = 0;
    }

    camera.x = Math.max(0, player.x - canvas.width / 2);

    // Vitória
    if (player.x < princess.x + princess.width &&
        player.x + player.width > princess.x &&
        player.y < princess.y + princess.height &&
        player.y + player.height > princess.y) {
        gameWon = true;
        victoryScreen.style.display = 'flex';
        // Tentar tocar música se o usuário já interagiu
        bgMusic.play().catch(e => console.log("Música aguardando interação"));
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Nuvens
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(100 - camera.x * 0.2, 50, 20, 0, Math.PI * 2);
    ctx.arc(120 - camera.x * 0.2, 50, 25, 0, Math.PI * 2);
    ctx.arc(140 - camera.x * 0.2, 50, 20, 0, Math.PI * 2);
    ctx.fill();

    // Plataformas
    ctx.fillStyle = '#8b4513';
    for (let p of platforms) {
        if (p.x + p.width > camera.x && p.x < camera.x + canvas.width) {
            ctx.fillRect(p.x - camera.x, p.y, p.width, p.height);
            ctx.fillStyle = '#228b22';
            ctx.fillRect(p.x - camera.x, p.y, p.width, 5);
            ctx.fillStyle = '#8b4513';
        }
    }

    // Princesa Rayane
    ctx.fillStyle = '#ff69b4';
    ctx.fillRect(princess.x - camera.x, princess.y, princess.width, princess.height);
    ctx.fillStyle = '#ffd700';
    ctx.fillRect(princess.x - camera.x + 5, princess.y - 5, 20, 5);
    ctx.fillStyle = '#ffdbac';
    ctx.fillRect(princess.x - camera.x + 7, princess.y + 5, 15, 15);

    player.draw();
}

function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
}

initLevel();
gameLoop();
